package com.coinman;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;

import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Logger;

import sun.rmi.runtime.Log;

public class CoinMan extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
	Texture[] man;
	Texture deadMan;
	int runningState=0,interval=0,coinInterval=0,bombInterval=0;
	float gravity=1,velocity=0;
	float many,manYmax;
	Random random;
	ArrayList<Integer> coinXValues,coinYValues,bombXValues,bombYValues;
	ArrayList<Rectangle> coinRectangles,bombRectangles;
	Texture coin,bomb;
	Rectangle coinMan;
	BitmapFont bitmapFont;
	int score=0,gameState=0;

	@Override
	public void create () {
		batch = new SpriteBatch();
		img=new Texture("bg.png");
		bomb=new Texture("bomb.png");
		deadMan=new Texture("dizzy-1.png");
		man=new Texture[4];
		man[0]=new Texture("frame-1.png");
		man[1]=new Texture("frame-2.png");
		man[2]=new Texture("frame-3.png");
		man[3]=new Texture("frame-4.png");
		coin=new Texture("coin.png");
		many=Gdx.graphics.getHeight()/2;
		manYmax=Gdx.graphics.getHeight()-man[0].getHeight()/2;
		random=new Random();
		coinXValues=new ArrayList<>();
		coinYValues=new ArrayList<>();
		bombXValues=new ArrayList<>();
		bombYValues=new ArrayList<>();
		coinRectangles=new ArrayList<>();
		bombRectangles=new ArrayList<>();
		bitmapFont=new BitmapFont();
		bitmapFont.setColor(Color.BLACK);
		bitmapFont.getData().setScale(10,10);
	}

	@Override
	public void render () {
		batch.begin();
		batch.draw(img,0,0,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
		if(gameState==0){
			if(Gdx.input.isTouched()){
				gameState=1;
				many=Gdx.graphics.getHeight()/2;
			}
		}
		else if(gameState==2){
			if(Gdx.input.isTouched()){
				velocity=0;
				score=0;
				many=Gdx.graphics.getHeight()/2;
				coinXValues.clear();
				coinYValues.clear();
				bombXValues.clear();
				bombYValues.clear();
				gameState=1;
			}
		}
		else if(gameState==1) {
			//limiting the max height to the screen height
			if (many > manYmax) {
				many = manYmax;
			}

			//generating the bombs at regular intervals
			bombRectangles.clear();
			if (bombInterval <= 200) {
				bombInterval++;
			} else {
				bombInterval = 0;
				bombXValues.add(Gdx.graphics.getWidth());
				float height = random.nextFloat() * Gdx.graphics.getHeight();
				bombYValues.add((int) height);
			}
			for (int i = 0; i < bombXValues.size(); i++) {
				bombXValues.set(i, bombXValues.get(i) - 18);
				batch.draw(bomb, bombXValues.get(i), bombYValues.get(i));
				bombRectangles.add(new Rectangle(bombXValues.get(i), bombYValues.get(i), bomb.getWidth(), bomb.getHeight()));
			}

			//generating the coins at regular intervals
			coinRectangles.clear();
			if (coinInterval <= 99) {
				coinInterval++;
			} else {
				coinInterval = 0;
				coinXValues.add(Gdx.graphics.getWidth());
				float height = random.nextFloat() * Gdx.graphics.getHeight();
				coinYValues.add((int) height);
			}
			for (int i = 0; i < coinXValues.size(); i++) {
				coinXValues.set(i, coinXValues.get(i) - 15);
				batch.draw(coin, coinXValues.get(i), coinYValues.get(i));
				coinRectangles.add(new Rectangle(coinXValues.get(i), coinYValues.get(i), coin.getWidth(), coin.getHeight()));
			}


			if (Gdx.input.isTouched()) {
				velocity = -20;
			}

			if (interval < 8) {
				interval++;
			} else {
				interval = 0;
				if (runningState < 3) {
					runningState++;
				} else {
					runningState = 0;
				}

			}
			velocity += gravity;
			many -= velocity;
			if (many < 0)
				many = 0;
		}
		////////////////////////////////////////////////////
		int width=Gdx.graphics.getWidth() / 2 - man[0].getWidth() / 2;
		int widthDummy=20;

		if(gameState<=1)
			batch.draw(man[runningState],widthDummy , many);
		else
			batch.draw(deadMan,widthDummy , many);
		coinMan=new Rectangle(widthDummy, many,man[runningState].getWidth(),man[runningState].getHeight());

		//checking for coin collision
		for(int i=0;i<coinRectangles.size();i++){
			if(Intersector.overlaps(coinMan,coinRectangles.get(i))){
				Gdx.app.log("Blast","coin blastes"+String.valueOf(i));
				coinXValues.remove(i);
				coinYValues.remove(i);
				coinRectangles.remove(i);
				score++;
				break;
			}
		}
        for(int i=0;i<bombRectangles.size();i++){
            if(Intersector.overlaps(coinMan,bombRectangles.get(i))){
                Gdx.app.log("Blast","bomb blastes"+String.valueOf(i));
				bombXValues.remove(i);
				bombYValues.remove(i);
				bombRectangles.remove(i);
				gameState=2;
				break;
            }
        }
        bitmapFont.draw(batch,String.valueOf(score),100,Gdx.graphics.getHeight());
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();

	}
}
